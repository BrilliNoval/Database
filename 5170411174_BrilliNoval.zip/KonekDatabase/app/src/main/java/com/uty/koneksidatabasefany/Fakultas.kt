package com.uty.koneksidatabasefany

class Fakultas {
    data class Fakultas (val id_fakultas:Int?, val kode_fakultas:String?, val nama_fakultas:String?)
}